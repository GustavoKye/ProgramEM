package com.programem.viajantes;

public class Lista {

    String listaUsuario(Iterable<Usuario>lista){
        return null;
        
    }
    
}