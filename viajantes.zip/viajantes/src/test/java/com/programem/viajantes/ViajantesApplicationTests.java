package com.programem.viajantes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViajantesApplicationTests {

	@Test
	void contextLoads() {
	}

}
